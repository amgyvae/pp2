#1st example
print(10 + 5)

#2nd example
print((6 + 3) - (6 + 3))
  
#3rd example
print(100 + 5 * 3)

#4th example
print(5 + 4 - 7 + 3)

