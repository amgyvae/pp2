#Exercise 1
print(10 > 9) #True

#Exercise 2
print(10 == 9) #False

#Exercise 3
print(10 < 9) #False

#Exercise 4
print(bool("abc")) #True

#Exercise 5
print(bool(0)) #False