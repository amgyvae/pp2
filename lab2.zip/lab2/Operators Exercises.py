
#Exercise 1
print(10 * 5)

#Exercise 2
print(10 / 2)

#Exercise 3
fruits = ["apple", "banana"]
if "apple" in fruits:
  print("Yes, apple is a fruit!")

#Exercise 4
if 5 != 10:
  print("5 and 10 is not equal")
  
#Exercise 5
if 5 == 10 or 4 == 4:
  print("At least one of the statements is true")
