#Exercise 1
fruits = ["apple", "banana", "cherry"]
print(fruits[1])

#Exercise 2
fruits = ["apple", "banana", "cherry"]
fruits[0] = "kiwi"

#Exercise 3
fruits = ["apple", "banana", "cherry"]
fruits.append("orange")

#Exercise 4
fruits = ["apple", "banana", "cherry"]
fruits.insert(1,"lemon")
  
#Exercise 5
fruits = ["apple", "banana", "cherry"]
fruits.remove("banana")

#Exercise 6
fruits = ["apple", "banana", "cherry"]
print(fruits[-1])

#Exercise 7
fruits = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(fruits[2:5])

#Exercise 8
fruits = ["apple", "banana", "cherry"]
print(len(fruits))
