#Exercise 1
a = 50
b = 10
if a > b:
  print("Hello World")

#Exercise 2
a = 50
b = 10
if a != b:
  print("Hello World")

#Exercise 3
a = 50
b = 10
if a == b:
  print("Yes")
else:
  print("No")

#Exercise 4
a = 50
b = 10
if a == b:
  print("1")
elif a > b:
  print("2")
else:
  print("3")
  
#Exercise 5
if a == b and c == d:
  print("Hello")

#Exercise 6
if a == b or c == d:
  print("Hello")

#Exercise 7
if 5 > 2:
    print("YES")

#Exercise 8
a = 2
b = 5
print("YES") if a == b else   print("NO")

#Exercise 9
a = 2
b = 50
c = 2
if a == c or b == c:
  print("YES")
