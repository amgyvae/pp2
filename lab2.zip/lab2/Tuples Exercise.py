#Exercise 1
fruits = ("apple", "banana", "cherry")
print(fruits[0])

#Exercise 2
fruits = ("apple", "banana", "cherry")
print(len(fruits))

#Exercise 3
fruits = ("apple", "banana", "cherry")
print(fruits[-1])

#Exercise 4
fruits = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(fruits[2:5])
  
