#Exercise 1
fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)

#Exercise 2
fruits = ["apple", "banana", "cherry"]
for x in fruits:
  if x == "banana":
    continue
  print(x)

#Exercise 3
for x in range(6):
  print(x)

#Exercise 4
fruits = ["apple", "banana", "cherry"]
for x in fruits:
  if x == "banana":    
    break
  print(x)
  