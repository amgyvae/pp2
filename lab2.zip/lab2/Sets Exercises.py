#Exercise 1
fruits = {"apple", "banana", "cherry"}
if "apple" in fruits:
  print("Yes, apple is a fruit!")

#Exercise 2
fruits = {"apple", "banana", "cherry"}
fruits.add("orange")

#Exercise 3
fruits = {"apple", "banana", "cherry"}
more_fruits = ["orange", "mango", "grapes"]
fruits.update(more_fruits)

#Exercise 4
fruits = {"apple", "banana", "cherry"}
fruits.remove("banana")

#Exercise 5
fruits = {"apple", "banana", "cherry"}
fruits.discard("banana")
